package am2.api.spell.enums;

public enum ContingencyTypes {
	NONE,
	FALL,
	DAMAGE_TAKEN,
	ON_FIRE,
	HEALTH_LOW, 
	DEATH
}
