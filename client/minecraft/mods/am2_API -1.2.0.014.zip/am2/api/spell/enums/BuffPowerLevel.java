package am2.api.spell.enums;

public class BuffPowerLevel {
	public static final int Low = 0;
	public static final int Medium = 1;
	public static final int High = 2;
}
