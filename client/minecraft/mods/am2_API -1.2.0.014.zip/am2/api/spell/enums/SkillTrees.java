package am2.api.spell.enums;

public enum SkillTrees {
	None,
	Offense,
	Defense,
	Utility,
	Talents,
	Familiar,
	Affinity
}
