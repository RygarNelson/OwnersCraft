package am2.api.spell.enums;

public enum SkillPointTypes{
	BLUE,
	GREEN,
	RED,
	SILVER
}
