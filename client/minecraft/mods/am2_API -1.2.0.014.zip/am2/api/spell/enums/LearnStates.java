package am2.api.spell.enums;

public enum LearnStates{
	LEARNED,
	CAN_LEARN,
	CANNOT_LEARN,
	LOCKED,
	DISABLED
};