package am2.api.illeffect;

public enum BadThingTypes{
	ALL, 
	DARKNEXUS
}