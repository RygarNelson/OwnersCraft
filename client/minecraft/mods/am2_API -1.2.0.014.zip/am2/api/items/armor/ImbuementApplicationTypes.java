package am2.api.items.armor;

public enum ImbuementApplicationTypes {
	NONE,
	ON_TICK,
	ON_HIT,
	ON_JUMP,
	ON_MINING_SPEED,
	ON_DEATH
}
