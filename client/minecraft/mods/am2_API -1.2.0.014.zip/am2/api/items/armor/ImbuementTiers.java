package am2.api.items.armor;

public enum ImbuementTiers {
	FIRST,
	SECOND,
	THIRD,
	FOURTH
}
